sls plugin install -n serverless-wsgi
sls plugin install -n serverless-python-requirements
sls plugin install -n serverless-dynamodb-local

sls dynamodb install