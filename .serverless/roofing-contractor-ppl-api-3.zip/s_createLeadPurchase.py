import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='groros',
    application_name='pay-per-lead-project',
    app_uid='rYNQcK70qD5VBMHF5w',
    org_uid='c80076b4-0fb8-4d01-aa02-43b773fcfe14',
    deployment_uid='93b219f4-da75-4d78-8e58-cda15fcaa70e',
    service_name='roofing-contractor-ppl-api-3',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'roofing-contractor-ppl-api-3-dev-createLeadPurchase', 'timeout': 10}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
